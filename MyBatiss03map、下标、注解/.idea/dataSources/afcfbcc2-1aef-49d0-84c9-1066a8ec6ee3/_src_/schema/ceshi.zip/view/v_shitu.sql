CREATE VIEW v_shitu AS
  SELECT
    `a`.`StuId`      AS `学号`,
    `a`.`StuName`    AS `姓名`,
    `b`.`TeaId`      AS `教师编号`,
    `b`.`TeaName`    AS `教师姓名`,
    `c`.`CourseId`   AS `课程编号`,
    `c`.`CourseName` AS `课程名称`,
    `d`.`Score`      AS `成绩`
  FROM `ceshi`.`tblstudent` `a`
    JOIN `ceshi`.`tblteacher` `b`
    JOIN `ceshi`.`tblcourse` `c`
    JOIN `ceshi`.`tblscore` `d`
  WHERE ((`a`.`StuId` = `d`.`StuId`) AND (`c`.`CourseId` = `d`.`CourseId`) AND (`b`.`TeaId` = `c`.`TeaId`));
